import React from 'react';

import './index.css';

const GameChat = () => <div className="chatWindowContainer">Chat</div>;

export default GameChat;